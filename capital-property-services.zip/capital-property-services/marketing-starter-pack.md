# Capital Property Services — Marketing Starter Pack
Prepared 2026-11-04, for approval before anything is posted or any ad spend is started.
Site: https://capitalpropertyservice.com
Phone: (571) 259-5510 — Mon–Sun 8am–7pm
Email: robelewaki@gmail.com
Service area: Alexandria, Arlington, Springfield, Annandale, Fairfax, Falls Church, Washington, DC, Silver Spring, Bethesda, Rockville, and surrounding DMV areas
Services: Air duct cleaning, Dryer vent cleaning, Chimney sweep & inspection, Chimney repair
Proof points from the site: 5.0 average rating, 10+ years hands-on experience, locally owned, upfront pricing, no-pressure estimates

## 1. Social media — ready-to-post drafts (no posting yet)

### Post A — Home quiz hook
Not sure what your home needs? Tap through it in 30 seconds.
Dusty air? Slow dryer? Fireplace smoke? Cracked chimney brick?
Tell us what's going on and we'll point you to the right service — no pressure, no obligation.
Get a free estimate: capitalpropertyservice.com | (571) 259-5510
Serving Alexandria and the greater DMV.

### Post B — Dryer safety
If your dryer takes forever, runs hot, or smells like burning, your vent may be clogged with lint.
That's a fire risk — and an easy fix.
Dryer vent cleaning, done carefully, with a cleanup every time.
Free estimate: capitalpropertyservice.com | (571) 259-5510

### Post C — Before-and-after trust
Professional, on time, and careful inside your house. Before-and-after photos, clear explanations, no scare tactics.
That's how we work on air ducts, dryer vents, and chimneys across the DMV.
Get a straightforward estimate: capitalpropertyservice.com

Suggested cadence to start: 2–3 posts per week, rotating quiz, safety tip, and customer-story angles. Use the site's before-and-after photos for the image posts.

## 2. Google / local search — Google Business Profile draft

Business name: Capital Property Services
Category: Air duct cleaning service (also: Chimney sweep, Dryer vent cleaning service)
Description: Locally owned home-service team in Alexandria, VA, serving the greater DMV. Air duct cleaning, dryer vent cleaning, chimney sweep & inspection, and chimney repair — with honest recommendations, upfront pricing, and respect for your home. Call or request a free estimate online.
Hours: Mon–Sun 8am–7pm
Phone: (571) 259-5510
Website: https://capitalpropertyservice.com
Service areas: Alexandria, Arlington, Springfield, Annandale, Fairfax, Falls Church, Washington, DC, Silver Spring, Bethesda, Rockville

First local-search actions (free):
- Create/claim the Google Business Profile with the details above, then add photos and the 4 services.
- Add the same name, phone, and service-area wording to the site footer and service pages for consistency.
- Ask happy customers for a Google review after each job, with a direct link once the profile is live.

Target search phrases to cover on the site and profile:
air duct cleaning Alexandria VA, dryer vent cleaning Alexandria, chimney sweep Alexandria VA, chimney repair DMV, air duct cleaning Arlington, dryer vent cleaning Fairfax

## 3. Paid ads — draft structure, NOT launched, no budget set yet

### Meta (Facebook/Instagram) — lead campaign, paused until approved
Objective: Leads to the free estimate form at capitalpropertyservice.com
Audience: Homeowners, 25–65, within ~25 miles of Alexandria, VA, interested in home improvement / home services
Ad 1 — Quiz angle: "Tap what's going on at your home — we'll point you to the right service."
Ad 2 — Safety angle: "Dryer taking forever? A clogged vent is a fire risk. Get a free estimate."
Ad 3 — Trust angle: "5.0-rated, locally owned, 10+ years. No pressure, just honest help."
Call to action: Get a free estimate / Call (571) 259-5510

### Google Search — draft, paused until approved
Headlines: Air Duct Cleaning Alexandria | Dryer Vent Cleaning DMV | Chimney Sweep & Repair | Free Estimate, No Pressure
Keywords: air duct cleaning Alexandria VA, dryer vent cleaning near me, chimney sweep Alexandria, chimney repair Fairfax VA
Landing page: https://capitalpropertyservice.com (estimate form)

## What is still needed before launch
1. Social: Do you already have Facebook/Instagram business pages for Capital Property Services? If so, their names/links. If not, I can draft the page setup for you to approve.
2. Google: Is there already a Google Business Profile, or should I set up a new one?
3. Ads: A monthly budget and a daily cap you are comfortable with, plus which ad account to use. Nothing will be spent until you approve a specific budget.
4. Photos: Confirm the site's before-and-after photos can be used in social/ads.

Backend note: This pack is separate from the backend wiring still running tonight (Resend/Postgres). Leads from marketing will use the same estimate form; durable storage and email notifications will switch on once that wiring flips to storage: database / email: true.
