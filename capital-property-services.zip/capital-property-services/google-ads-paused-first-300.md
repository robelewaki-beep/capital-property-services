# Google Ads — Paused-first $300 test plan for Capital Property Services
Prepared 2026-11-05 ~12:17pm EST, for the user's approval. NOT launched, NOTHING spent.
Account: Google Ads 767-953-0121 (offer applied: spend $500 in 60 days to unlock $500 credit — this plan does NOT chase that credit; it uses the original $300 budget instead).
Landing page: https://capitalpropertyservice.com (free-estimate form / home-issue quiz)
Phone: (571) 259-5510 — Mon–Sun 8am–7pm
Service areas: Alexandria, Arlington, Springfield, Annandale, Fairfax, Falls Church, Washington DC, Silver Spring, Bethesda, Rockville

## Budget — the $300 ceiling, made concrete
- Total test budget: $300 (the figure the user set on 2026-11-04).
- Daily cap: $10/day. At $10/day the $300 lasts ~30 days; pause or stop any time.
- Alternative if the user wants faster learning: $20/day for ~15 days — same $300 total, not offered as a default.
- This plan assumes $300 is a total test budget, not monthly recurring. If the user meant $300/month, the same $10/day cap still fits.
- No payment method is connected yet. Google requires a payment profile + valid payment method during sign-up to finish claiming/launching. That step is the user's — no card is added by this plan.

## Campaign structure (Search, paused on build)
One campaign, "CPS — Search — DMV", location: Alexandria + 25-mile radius, language English, paused at build.
Three ad groups, one per service, so spend can be judged per service:

### Ad group 1 — Air duct cleaning
Keywords (phrase / exact intent): air duct cleaning Alexandria VA, air duct cleaning Arlington, air duct cleaning Fairfax VA, air duct cleaning near me, air duct cleaning DMV
Headlines: Air Duct Cleaning Alexandria | Free Estimate — No Pressure | 5.0-Rated Local Team | 10+ Years Hands-On Experience | Mon–Sun 8am–7pm
Descriptions: Locally owned air duct cleaning across Alexandria and the DMV. Upfront pricing, careful in your home. / Tell us what's going on — get a free estimate at capitalpropertyservice.com or call (571) 259-5510.

### Ad group 2 — Dryer vent cleaning
Keywords: dryer vent cleaning Alexandria, dryer vent cleaning Fairfax, dryer vent cleaning near me, dryer vent cleaning Arlington VA, clogged dryer vent repair
Headlines: Dryer Vent Cleaning DMV | Dryer Slow, Hot or Smelly? | Clogged Vent = Fire Risk | Free Estimate — Call (571) 259-5510
Descriptions: Dryer taking forever or running hot? A clogged vent is a fire risk — and an easy fix, with cleanup every time. / Free estimate, no pressure. Serving Alexandria and the greater DMV, Mon–Sun 8am–7pm.

### Ad group 3 — Chimney sweep & repair
Keywords: chimney sweep Alexandria VA, chimney sweep near me, chimney inspection Alexandria, chimney repair Fairfax VA, chimney repair DMV
Headlines: Chimney Sweep & Repair | Chimney Sweep Alexandria VA | Fireplace Smoke? Get It Checked | Free Estimate, No Pressure
Descriptions: Chimney sweep, inspection and repair from a locally owned Alexandria team. Honest recommendations, upfront pricing. / Book a free estimate at capitalpropertyservice.com or call (571) 259-5510.

## Negative keywords (avoid wasted spend)
free DIY, jobs, hiring, training, certification, supplies, parts, "how to clean air ducts yourself", duct cleaning machine for sale

## What "paused first" means
- Build the campaign in account 767-953-0121 with status Paused.
- User approves the exact headlines, keywords, $10/day cap and $300 total before anything goes live.
- Only after that approval: add payment method (user), unpause, and watch the first days' spend/search terms before scaling.
- If the user instead picks the $500-credit route, this plan changes: spend $500 in 60 days first, then $500 credit arrives — that is above the $300 ceiling and needs a separate explicit go-ahead.

## Still needed before any launch
1. User's choice: this paused-first $300 plan (recommended default), the $500-credit route, or the $300 budget launched live — they are different on spend.
2. A payment method added by the user in Google Ads (not added here, no card requested in chat).
3. Confirmation the $300 is a total test budget (assumed above) vs monthly.

## Sources for the facts above
- $300 budget, services, phone, hours, areas and proof points: marketing starter pack, ~/workspace/capital-property-services/marketing-starter-pack.md (prepared 2026-11-04).
- Ads account 767-953-0121, $500 offer applied, no payment method / no campaign / nothing spent, and the three-way choice pending: conversation 2026-11-05 11:50am EST.
- Site live with Mon–Sun 8am–7pm and backend email/database on: verified 2026-11-05 11:19am EST, health {"ok":true,"storage":"database","email":true}.
