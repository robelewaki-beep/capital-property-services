const menuButton = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');

if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', open);
  });

  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
    });
  });
}

const year = document.querySelector('#year');

if (year) {
  year.textContent = new Date().getFullYear();
}

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.reveal').forEach(element => {
  observer.observe(element);
});

const quoteForm = document.querySelector('#quote');

if (quoteForm) {

  let formMessage = document.querySelector('#form-message');

  if (!formMessage) {
    formMessage = document.createElement('div');
    formMessage.id = 'form-message';

    const submitButton =
      quoteForm.querySelector('button[type="submit"]');

    submitButton.insertAdjacentElement(
      'afterend',
      formMessage
    );
  }

  formMessage.style.display = 'none';
  formMessage.style.marginTop = '16px';
  formMessage.style.padding = '14px 16px';
  formMessage.style.borderRadius = '10px';
  formMessage.style.fontWeight = '600';
  formMessage.style.lineHeight = '1.5';

  quoteForm.addEventListener('submit', async event => {
    event.preventDefault();

    const form = event.currentTarget;
    const button =
      form.querySelector('button[type="submit"]');

    const originalText = button.innerHTML;

    button.disabled = true;
    button.textContent = 'Sending...';

    formMessage.style.display = 'none';

    try {

      const response = await fetch('/api/quotes', {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json'
        },

        body: JSON.stringify(
          Object.fromEntries(
            new FormData(form)
          )
        )
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.error ||
          'Unable to send your request.'
        );
      }

      form.reset();

      // Google Ads conversion: fire "Submit lead form" only on a successful submit
      if (typeof gtag === 'function') {
        gtag('event', 'conversion', {
          'send_to': 'AW-18558387472/VuANCKLL0bQdEJCKqpFF',
          'value': 1.0,
          'currency': 'USD'
        });
      }

      formMessage.textContent =
        '✓ Thank you! Your estimate request was sent successfully. We’ll contact you shortly.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#eaf8ef';
      formMessage.style.border =
        '1px solid #b7dfc3';
      formMessage.style.color = '#1f6b37';

      formMessage.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });

    } catch (error) {

      formMessage.textContent =
        error.message ||
        'Unable to send your request. Please call (571) 259-5510 instead.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#fff0f0';
      formMessage.style.border =
        '1px solid #e2b2b2';
      formMessage.style.color = '#9b2222';

    } finally {

      button.disabled = false;
      button.innerHTML = originalText;

    }
  });
}

// --- Interactive upgrades: service picker, quiz, reviews highlight, back-to-top ---
const serviceSelect = document.querySelector('select[name="service"]');
function preselectService(service) {
  if (!serviceSelect) return;
  serviceSelect.value = service;
  serviceSelect.style.borderColor = '#70a777';
  serviceSelect.style.boxShadow = '0 0 0 3px rgba(112,167,119,.25)';
  setTimeout(() => { serviceSelect.style.boxShadow = 'none'; }, 1500);
}
document.querySelectorAll('.service-pick').forEach(link => {
  link.addEventListener('click', () => preselectService(link.dataset.service));
});
const quizResult = document.querySelector('#quiz-result');
const quizText = document.querySelector('#quiz-result-text');
document.querySelectorAll('.quiz-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.quiz-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    preselectService(card.dataset.quizService);
    if (quizResult && quizText) {
      quizText.textContent = 'Recommended: ' + card.dataset.quizService + '. ' + card.dataset.quizNote;
      quizResult.style.display = 'flex';
      quizResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });
});
// Rotating review highlight
const reviews = document.querySelectorAll('.review-grid blockquote');
if (reviews.length) {
  let ri = 0;
  const highlight = () => {
    reviews.forEach((r, i) => r.classList.toggle('review-active', i === ri));
    ri = (ri + 1) % reviews.length;
  };
  highlight();
  setInterval(highlight, 5000);
}
// Back to top + header shadow on scroll
const backBtn = document.querySelector('#back-to-top');
const header = document.querySelector('.header');
window.addEventListener('scroll', () => {
  if (backBtn) backBtn.classList.toggle('show', window.scrollY > 600);
  if (header) header.style.boxShadow = window.scrollY > 10 ? '0 8px 24px rgba(10,35,38,.10)' : 'none';
}, { passive: true });
// Animated counters for elements with data-count
const counters = document.querySelectorAll('[data-count]');
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el = entry.target;
    const target = Number(el.dataset.count);
    let n = 0;
    const step = () => {
      n += Math.max(1, Math.round(target / 30));
      if (n >= target) { el.textContent = target + (el.dataset.suffix || ''); counterObserver.unobserve(el); }
      else { el.textContent = n; requestAnimationFrame(step); }
    };
    step();
  });
}, { threshold: 0.5 });
counters.forEach(el => counterObserver.observe(el));
