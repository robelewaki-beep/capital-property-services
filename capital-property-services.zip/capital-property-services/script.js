const menuButton = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');

if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', open);
  });

  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
    });
  });
}

const year = document.querySelector('#year');

if (year) {
  year.textContent = new Date().getFullYear();
}

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.reveal').forEach(element => {
  observer.observe(element);
});

const quoteForm = document.querySelector('#quote');

if (quoteForm) {

  let formMessage = document.querySelector('#form-message');

  if (!formMessage) {
    formMessage = document.createElement('div');
    formMessage.id = 'form-message';

    const submitButton =
      quoteForm.querySelector('button[type="submit"]');

    submitButton.insertAdjacentElement(
      'afterend',
      formMessage
    );
  }

  formMessage.style.display = 'none';
  formMessage.style.marginTop = '16px';
  formMessage.style.padding = '14px 16px';
  formMessage.style.borderRadius = '10px';
  formMessage.style.fontWeight = '600';
  formMessage.style.lineHeight = '1.5';

  quoteForm.addEventListener('submit', async event => {
    event.preventDefault();

    const form = event.currentTarget;
    const button =
      form.querySelector('button[type="submit"]');

    const originalText = button.innerHTML;

    button.disabled = true;
    button.textContent = 'Sending...';

    formMessage.style.display = 'none';

    try {

      const response = await fetch('/api/quotes', {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json'
        },

        body: JSON.stringify(
          Object.fromEntries(
            new FormData(form)
          )
        )
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.error ||
          'Unable to send your request.'
        );
      }

      form.reset();

      formMessage.textContent =
        '✓ Thank you! Your estimate request was sent successfully. We’ll contact you shortly.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#eaf8ef';
      formMessage.style.border =
        '1px solid #b7dfc3';
      formMessage.style.color = '#1f6b37';

      formMessage.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });

    } catch (error) {

      formMessage.textContent =
        error.message ||
        'Unable to send your request. Please call (571) 259-5510 instead.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#fff0f0';
      formMessage.style.border =
        '1px solid #e2b2b2';
      formMessage.style.color = '#9b2222';

    } finally {

      button.disabled = false;
      button.innerHTML = originalText;

    }
  });
}
