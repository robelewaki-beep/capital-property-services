const menuButton = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');

if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', open);
  });

  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
    });
  });
}

const year = document.querySelector('#year');

if (year) {
  year.textContent = new Date().getFullYear();
}

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.reveal').forEach(element => {
  observer.observe(element);
});

const quoteForm = document.querySelector('#quote');

if (quoteForm) {

  let formMessage = document.querySelector('#form-message');

  if (!formMessage) {
    formMessage = document.createElement('div');
    formMessage.id = 'form-message';

    const submitButton =
      quoteForm.querySelector('button[type="submit"]');

    submitButton.insertAdjacentElement(
      'afterend',
      formMessage
    );
  }

  formMessage.style.display = 'none';
  formMessage.style.marginTop = '16px';
  formMessage.style.padding = '14px 16px';
  formMessage.style.borderRadius = '10px';
  formMessage.style.fontWeight = '600';
  formMessage.style.lineHeight = '1.5';

  quoteForm.addEventListener('submit', async event => {
    event.preventDefault();

    const form = event.currentTarget;
    const button =
      form.querySelector('button[type="submit"]');

    const originalText = button.innerHTML;

    button.disabled = true;
    button.textContent = 'Sending...';

    formMessage.style.display = 'none';

    try {

      const payload = Object.fromEntries(new FormData(form));
      const prefDate = payload.preferred_date || '';
      const prefTime = payload.preferred_time || '';
      if (prefDate || prefTime) {
        payload.message = (payload.message ? payload.message + '\n' : '') + 'Preferred: ' + (prefDate || 'any date') + ', ' + (prefTime || 'any time');
      }

      const response = await fetch('/api/quotes', {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json'
        },

        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.error ||
          'Unable to send your request.'
        );
      }

      form.reset();

      // Google Ads conversion: fire "Submit lead form" only on a successful submit
      if (typeof gtag === 'function') {
        gtag('event', 'conversion', {
          'send_to': 'AW-18558387472/VuANCKLL0bQdEJCKqpFF',
          'value': 1.0,
          'currency': 'USD'
        });
      }

      formMessage.textContent =
        '✓ Thank you! Your estimate request was sent successfully. We’ll contact you shortly.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#eaf8ef';
      formMessage.style.border =
        '1px solid #b7dfc3';
      formMessage.style.color = '#1f6b37';

      formMessage.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });

    } catch (error) {

      formMessage.textContent =
        error.message ||
        'Unable to send your request. Please call (571) 259-5510 instead.';

      formMessage.style.display = 'block';
      formMessage.style.background = '#fff0f0';
      formMessage.style.border =
        '1px solid #e2b2b2';
      formMessage.style.color = '#9b2222';

    } finally {

      button.disabled = false;
      button.innerHTML = originalText;

    }
  });
}

// --- Interactive upgrades: service picker, quiz, reviews highlight, back-to-top ---
const serviceSelect = document.querySelector('select[name="service"]');
function preselectService(service) {
  if (!serviceSelect) return;
  serviceSelect.value = service;
  serviceSelect.style.borderColor = '#70a777';
  serviceSelect.style.boxShadow = '0 0 0 3px rgba(112,167,119,.25)';
  setTimeout(() => { serviceSelect.style.boxShadow = 'none'; }, 1500);
}
document.querySelectorAll('.service-pick').forEach(link => {
  link.addEventListener('click', () => preselectService(link.dataset.service));
});
const quizResult = document.querySelector('#quiz-result');
const quizText = document.querySelector('#quiz-result-text');
document.querySelectorAll('.quiz-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.quiz-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    preselectService(card.dataset.quizService);
    if (quizResult && quizText) {
      quizText.textContent = 'Recommended: ' + card.dataset.quizService + '. ' + card.dataset.quizNote;
      quizResult.style.display = 'flex';
      quizResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  });
});
// Rotating review highlight
const reviews = document.querySelectorAll('.review-grid blockquote');
if (reviews.length) {
  let ri = 0;
  const highlight = () => {
    reviews.forEach((r, i) => r.classList.toggle('review-active', i === ri));
    ri = (ri + 1) % reviews.length;
  };
  highlight();
  setInterval(highlight, 5000);
}
// Back to top + header shadow on scroll
const backBtn = document.querySelector('#back-to-top');
const header = document.querySelector('.header');
window.addEventListener('scroll', () => {
  if (backBtn) backBtn.classList.toggle('show', window.scrollY > 600);
  if (header) header.style.boxShadow = window.scrollY > 10 ? '0 8px 24px rgba(10,35,38,.10)' : 'none';
}, { passive: true });
// Animated counters for elements with data-count
const counters = document.querySelectorAll('[data-count]');
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el = entry.target;
    const target = Number(el.dataset.count);
    let n = 0;
    const step = () => {
      n += Math.max(1, Math.round(target / 30));
      if (n >= target) { el.textContent = target + (el.dataset.suffix || ''); counterObserver.unobserve(el); }
      else { el.textContent = n; requestAnimationFrame(step); }
    };
    step();
  });
}, { threshold: 0.5 });
counters.forEach(el => counterObserver.observe(el));

// --- ZIP checker (Areas section) ---
const zipInput = document.querySelector('#zip-check-input');
const zipBtn = document.querySelector('#zip-check-btn');
const zipResult = document.querySelector('#zip-check-result');
const servedZips = ['22301','22302','22303','22304','22305','22306','22307','22308','22309','22310','22311','22312','22313','22314','22315','22201','22202','22203','22204','22205','22206','22207','22209','22210','22211','22212','22213','22003','22015','22027','22030','22031','22032','22033','22041','22042','22043','22044','22046','22101','22102','22103','22180','22181','22182','20001','20002','20003','20004','20005','20006','20007','20008','20009','20010','20011','20012','20015','20016','20017','20018','20019','20020','20032','20036','20037','20901','20902','20903','20904','20905','20906','20910','20912','20814','20815','20816','20817','20852','20853','20854'];
if (zipBtn && zipInput && zipResult) {
  zipBtn.addEventListener('click', () => {
    const z = zipInput.value.trim();
    zipResult.style.display = 'block';
    if (!/^\d{5}$/.test(z)) { zipResult.textContent = 'Enter a 5-digit ZIP code.'; zipResult.className = 'zip-check-result-no'; return; }
    if (servedZips.includes(z)) {
      zipResult.textContent = 'Yes — we serve ' + z + '! Fill in the estimate form above and we will confirm your time.';
      zipResult.className = 'zip-check-result-ok';
      const formZip = document.querySelector('input[name="zip"]');
      if (formZip) formZip.value = z;
    } else {
      zipResult.textContent = 'We may still cover ' + z + ' — send the form and we will confirm, or call (571) 259-5510.';
      zipResult.className = 'zip-check-result-no';
    }
  });
}
