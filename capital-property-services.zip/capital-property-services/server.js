'use strict';

const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

loadEnv();

const ROOT = __dirname;
const DATA_DIR = path.resolve(
  process.env.DATA_DIR || path.join(ROOT, 'data')
);
const QUOTES_FILE = path.join(DATA_DIR, 'quotes.json');
const PORT = Number(process.env.PORT) || 3000;

// Optional persistent storage for now: a free Render PostgreSQL
// database, linked as DATABASE_URL. If it is set, leads go there
// (and survive free-service sleeps/restarts); otherwise they fall
// back to the local quotes.json file, as before.
let dbPool = null;
let dbReady = false;
if (process.env.DATABASE_URL) {
  try {
    const { Pool } = require('pg');
    dbPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false }
    });
    dbPool.query(
      `CREATE TABLE IF NOT EXISTS leads (
        id TEXT PRIMARY KEY,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        status TEXT NOT NULL DEFAULT 'new',
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT NOT NULL,
        service TEXT NOT NULL,
        zip TEXT NOT NULL DEFAULT '',
        message TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT 'website'
      )`
    ).then(() => { dbReady = true; }).catch(err => {
      console.error('Database init failed, using file storage:', err.message);
      dbPool = null;
    });
  } catch (err) {
    console.error('pg not available, using file storage:', err.message);
    dbPool = null;
  }
}
const attempts = new Map();

const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml'
};

http.createServer(async (req, res) => {
  secure(res);

  try {
    const url = new URL(
      req.url,
      `http://${req.headers.host || 'localhost'}`
    );

    if (
      req.method === 'POST' &&
      url.pathname === '/api/quotes'
    ) {
      return await submitQuote(req, res);
    }

    if (
      req.method === 'GET' &&
      url.pathname === '/api/admin/quotes'
    ) {
      return await getQuotes(req, res);
    }

    if (
      req.method === 'GET' &&
      url.pathname === '/api/health'
    ) {
      return json(res, 200, {
        ok: true,
        storage: dbPool ? 'database' : 'file',
        email: Boolean(
          process.env.RESEND_API_KEY &&
          process.env.NOTIFY_EMAIL &&
          process.env.FROM_EMAIL
        )
      });
    }

    if (req.method !== 'GET') {
      return json(res, 405, {
        error: 'Method not allowed.'
      });
    }

    return await staticFile(url.pathname, res);

  } catch (error) {
    console.error(error);

    return json(res, 500, {
      error: 'Something went wrong. Please call us instead.'
    });
  }

}).listen(PORT, () => {
  console.log(
    `Capital Property Services: http://localhost:${PORT}`
  );
});

async function submitQuote(req, res) {
  const ip = String(
    req.headers['x-forwarded-for'] ||
    req.socket.remoteAddress ||
    'unknown'
  )
    .split(',')[0]
    .trim();

  if (limited(ip)) {
    return json(res, 429, {
      error: 'Too many requests. Please wait or call us.'
    });
  }

  const input = await body(req);

  if (!input) {
    return json(res, 400, {
      error: 'Invalid request.'
    });
  }

  if (input.website) {
    return json(res, 200, {
      ok: true
    });
  }

  const cleaned = validate(input);

  if (cleaned.error) {
    return json(res, 422, {
      error: cleaned.error
    });
  }

  const quote = {
    id: `CPS-${Date.now()
      .toString(36)
      .toUpperCase()}-${crypto
      .randomBytes(2)
      .toString('hex')
      .toUpperCase()}`,

    createdAt: new Date().toISOString(),
    status: 'new',
    ...cleaned,
    source: 'website'
  };

  const stored = await save(quote);

  const emailed = await notify(quote);

  return json(res, 201, {
    ok: true,
    quoteId: quote.id,
    emailed,
    stored,
    message:
      'Thanks! We received your request and will contact you shortly.'
  });
}

async function getQuotes(req, res) {
  const expected = process.env.ADMIN_API_KEY || '';

  const supplied = (
    req.headers.authorization || ''
  ).replace(/^Bearer\s+/i, '');

  if (!expected) {
    return json(res, 503, {
      error: 'Admin access is not configured.'
    });
  }

  if (!equal(expected, supplied)) {
    return json(res, 401, {
      error: 'Unauthorized.'
    });
  }

  const quotes = await read();

  return json(res, 200, {
    count: quotes.length,
    quotes: quotes.reverse()
  });
}

function validate(input) {
  const clean = (value, max) =>
    String(value || '')
      .trim()
      .slice(0, max);

  const name = clean(input.name, 80);
  const phone = clean(input.phone, 30);
  const email = clean(input.email, 120).toLowerCase();
  const service = clean(input.service, 80);
  const zip = clean(input.zip, 10);
  const message = clean(input.message, 1500);

  const services = new Set([
    'Air duct cleaning',
    'Dryer vent cleaning',
    'Chimney sweep & inspection',
    'Chimney repair',
    'Chimney + Dryer Vent bundle — $149'
  ]);

  if (name.length < 2) {
    return {
      error: 'Please enter your name.'
    };
  }

  if (!/^[+()\d\s.-]{7,30}$/.test(phone)) {
    return {
      error: 'Please enter a valid phone number.'
    };
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return {
      error: 'Please enter a valid email address.'
    };
  }

  if (!services.has(service)) {
    return {
      error: 'Please choose a service.'
    };
  }

  if (
    zip &&
    !/^\d{5}(-\d{4})?$/.test(zip)
  ) {
    return {
      error: 'Please enter a valid ZIP code.'
    };
  }

  return {
    name,
    phone,
    email,
    service,
    zip,
    message
  };
}

async function save(quote) {
  if (dbPool) {
    try {
      await dbPool.query(
        `INSERT INTO leads
          (id, name, phone, email, service, zip, message, source)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (id) DO NOTHING`,
        [quote.id, quote.name, quote.phone, quote.email,
         quote.service, quote.zip || '', quote.message || '',
         quote.source || 'website']
      );
      return 'database';
    } catch (error) {
      console.error('Database save failed, falling back to file:', error.message);
    }
  }

  const quotes = await readFileQuotes();

  quotes.push(quote);

  await fs.mkdir(DATA_DIR, {
    recursive: true
  });

  await fs.writeFile(
    QUOTES_FILE,
    JSON.stringify(quotes, null, 2),
    {
      mode: 0o600
    }
  );
  return 'file';
}

async function read() {
  if (dbPool) {
    try {
      const result = await dbPool.query(
        `SELECT id, created_at, status, name, phone, email,
                service, zip, message, source
         FROM leads ORDER BY created_at DESC`
      );
      return result.rows.map(row => ({
        id: row.id,
        createdAt: row.created_at ? row.created_at.toISOString() : null,
        status: row.status,
        name: row.name,
        phone: row.phone,
        email: row.email,
        service: row.service,
        zip: row.zip,
        message: row.message,
        source: row.source
      }));
    } catch (error) {
      console.error('Database read failed, falling back to file:', error.message);
    }
  }
  return readFileQuotes();
}

async function readFileQuotes() {
  try {
    const value = JSON.parse(
      await fs.readFile(
        QUOTES_FILE,
        'utf8'
      )
    );

    return Array.isArray(value)
      ? value
      : [];

  } catch (error) {
    if (error.code === 'ENOENT') {
      return [];
    }

    throw error;
  }
}

async function notify(q) {
  const key = process.env.RESEND_API_KEY;
  const to = process.env.NOTIFY_EMAIL;
  const from = process.env.FROM_EMAIL;

  if (!key || !to || !from) {
    return false;
  }

  try {
    const response = await fetch(
      'https://api.resend.com/emails',
      {
        method: 'POST',

        headers: {
          Authorization: `Bearer ${key}`,
          'Content-Type': 'application/json'
        },

        body: JSON.stringify({
          from,
          to: [to],
          reply_to: q.email,

          subject:
            `New ${q.service} lead — ${q.name}`,

          text:
`Lead: ${q.id}
Name: ${q.name}
Phone: ${q.phone}
Email: ${q.email}
Service: ${q.service}
ZIP: ${q.zip || 'Not provided'}

${q.message || 'No message.'}`
        })
      }
    );

    if (!response.ok) {
      console.error(
        'Email failed:',
        response.status,
        await response.text()
      );
    }

    return response.ok;

  } catch (error) {
    console.error(
      'Email failed:',
      error.message
    );

    return false;
  }
}

async function body(req) {
  let raw = '';

  for await (const chunk of req) {
    raw += chunk;

    if (
      Buffer.byteLength(raw) > 20000
    ) {
      return null;
    }
  }

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function limited(ip) {
  const now = Date.now();

  const recent = (
    attempts.get(ip) || []
  ).filter(
    time => now - time < 900000
  );

  recent.push(now);

  attempts.set(ip, recent);

  return recent.length > 5;
}

function equal(a, b) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);

  return (
    x.length === y.length &&
    crypto.timingSafeEqual(x, y)
  );
}

async function staticFile(
  urlPath,
  res
) {
  let relative =
    urlPath === '/'
      ? 'index.html'
      : decodeURIComponent(
          urlPath
        ).replace(/^\/+/, '');

  if (relative.includes('..')) {
    return json(res, 400, {
      error: 'Invalid path.'
    });
  }

  const file = path.join(
    ROOT,
    relative
  );

  const ext = path
    .extname(file)
    .toLowerCase();

  try {
    const data =
      await fs.readFile(file);

    const cacheControl =
      ext === '.html' ||
      ext === '.js' ||
      ext === '.css'
        ? 'no-cache'
        : 'public, max-age=604800';

    res.writeHead(200, {
      'Content-Type':
        types[ext] ||
        'application/octet-stream',

      'Content-Length':
        data.length,

      'Cache-Control':
        cacheControl
    });

    res.end(data);

  } catch (error) {
    if (
      error.code === 'ENOENT'
    ) {
      return json(res, 404, {
        error: 'Not found.'
      });
    }

    throw error;
  }
}

function json(
  res,
  status,
  payload
) {
  const data =
    JSON.stringify(payload);

  res.writeHead(status, {
    'Content-Type':
      'application/json; charset=utf-8',

    'Content-Length':
      Buffer.byteLength(data)
  });

  res.end(data);
}

function secure(res) {
  res.setHeader(
    'X-Content-Type-Options',
    'nosniff'
  );

  res.setHeader(
    'X-Frame-Options',
    'SAMEORIGIN'
  );

  res.setHeader(
    'Referrer-Policy',
    'strict-origin-when-cross-origin'
  );

  res.setHeader(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=()'
  );
}

function loadEnv() {
  try {
    const raw =
      require('node:fs')
        .readFileSync(
          path.join(
            __dirname,
            '.env'
          ),
          'utf8'
        );

    for (
      const line of raw.split(
        /\r?\n/
      )
    ) {
      const m =
        line.match(
          /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/
        );

      if (
        m &&
        m[2] &&
        !(m[1] in process.env)
      ) {
        process.env[m[1]] =
          m[2]
            .trim()
            .replace(
              /^(['"])(.*)\1$/,
              '$2'
            );
      }
    }

  } catch (error) {
    if (
      error.code !== 'ENOENT'
    ) {
      throw error;
    }
  }
}
