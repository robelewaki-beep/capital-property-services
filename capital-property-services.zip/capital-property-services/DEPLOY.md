# Deploy (Render, instead of Railway)

1. Push this folder to a GitHub repository, or use Render's dashboard upload/Git deploy.
2. In Render, create a Web Service from that repo.
   - Build: npm install (no dependencies, so this is a no-op)
   - Start: npm start
   - Health check: /api/health
3. Environment variables:
   - DATA_DIR=/data
   - ADMIN_API_KEY=<a long random secret - do not share it in chat>
   - RESEND_API_KEY, NOTIFY_EMAIL, FROM_EMAIL: optional, only if lead emails are wanted
4. Persistent disk: attach a disk mounted at /data (paid instances only on Render; free instances have an ephemeral filesystem and will lose saved quotes on spin-down/redeploy).
5. Custom domain: add capitalpropertyservice.com in Render's Custom Domains. Render will show the exact DNS record to add.
6. In Porkbun, for capitalpropertyservice.com, add the DNS record Render shows (apex domains typically use an A record, subdomains use a CNAME), then wait for DNS propagation and verify https://capitalpropertyservice.com and https://capitalpropertyservice.com/api/health
