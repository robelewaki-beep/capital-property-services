# Capital Property Services

Responsive service-business website with a dependency-free Node.js backend.

## Run locally

1. Copy `.env.example` to `.env`.
2. Replace `ADMIN_API_KEY` with a long random value.
3. Run `npm start`.
4. Open `http://localhost:3000`.

Quote requests are saved in `data/quotes.json`. View them through:

```bash
curl http://localhost:3000/api/admin/quotes \
  -H "Authorization: Bearer YOUR_ADMIN_API_KEY"
```

## Deploy on Railway

1. Put this project in a GitHub repository.
2. In Railway, create a project and choose **Deploy from GitHub repo**.
3. Add these Variables:
   - `ADMIN_API_KEY`: a long random secret
   - `DATA_DIR`: `/data`
   - `RESEND_API_KEY`: optional, for lead emails
   - `NOTIFY_EMAIL`: optional, your business inbox
   - `FROM_EMAIL`: optional, verified sending address
4. Add a Railway Volume mounted at `/data` so leads survive deployments.
5. Generate a Railway domain or connect your custom domain.

The included `railway.toml` sets the start command and health check automatically.

## API

- `POST /api/quotes` — accepts website quote requests
- `GET /api/admin/quotes` — requires `Authorization: Bearer <ADMIN_API_KEY>`
- `GET /api/health` — deployment health check

The backend includes server-side validation, basic IP rate limiting, a spam honeypot, protected lead access, and optional Resend email notifications.
